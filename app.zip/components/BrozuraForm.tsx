"use client";

import { useActionState, useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import type { Brozura } from "@prisma/client";
import {
  createBrozura,
  updateBrozura,
  type BrozuraFormState,
} from "@/lib/actions/brozury";
import { BrozuraNahled, type BrozuraData, TEMA_TMAVE, TEMA_SVETLE } from "@/components/BrozuraNahled";

// ─── Options ─────────────────────────────────────────────────────────────────

const SABLONA_OPTIONS = [
  { value: "AKCE",           label: "🎭 Kulturní akce / Koncert" },
  { value: "ZVERINOVE_HODY", label: "🦌 Zvěřinové hody / Speciální menu" },
  { value: "UBYTOVANI",      label: "🛏️ Nabídka ubytování" },
  { value: "RESTAURACE",     label: "🍽️ Promo restaurace" },
  { value: "VSEOBECNE",      label: "📄 Univerzální šablona" },
];

const KATEGORIE_OPTIONS = [
  { value: "AKCE",      label: "Akce" },
  { value: "MENU",      label: "Menu" },
  { value: "UBYTOVANI", label: "Ubytování" },
  { value: "SPORTOVNI", label: "Sportovní" },
  { value: "OSTATNI",   label: "Ostatní" },
];

const FORMAT_OPTIONS = [
  { value: "A3", label: "A3 (297×420 mm)" },
  { value: "A4", label: "A4 (210×297 mm)" },
  { value: "A5", label: "A5 (148×210 mm)" },
];

const ORIENTACE_OPTIONS = [
  { value: "PORTRAIT",  label: "Na výšku (portrait)" },
  { value: "LANDSCAPE", label: "Na šírku (landscape)" },
];

const LAYOUT_OPTIONS = [
  { value: "KLASICKY", label: "Klasický — centrovaný, formální" },
  { value: "MAGAZIN",  label: "Magazín — hero foto nahoře" },
  { value: "MINIMA",   label: "Minimalistický — čistý, moderní" },
  { value: "SIROKY",   label: "Dvousloupcový — foto + obsah" },
];

const STAV_OPTIONS = [
  { value: "ROZPRACOVANA", label: "Rozpracovaná" },
  { value: "HOTOVA",       label: "Hotová" },
  { value: "ARCHIV",       label: "Archiv" },
];

// ─── Helpers ─────────────────────────────────────────────────────────────────

function defaultPreview(b?: Brozura | null): BrozuraData {
  const tema = (b as any)?.tema || "TMAVE";
  const defaultColors = tema === "SVETLE" ? TEMA_SVETLE : TEMA_TMAVE;
  return {
    sablona:      (b as any)?.sablona      || "AKCE",
    format:       (b as any)?.format       || "A4",
    orientace:    (b as any)?.orientace    || "PORTRAIT",
    layout:       (b as any)?.layout       || "KLASICKY",
    tema:                                     tema,
    barvaPozadi:  (b as any)?.barvaPozadi  || defaultColors.barvaPozadi,
    barvaText:    (b as any)?.barvaText    || defaultColors.barvaText,
    barvaAkcentu: (b as any)?.barvaAkcentu || defaultColors.barvaAkcentu,
    nadpis:       b?.nadpis                || "Název akce",
    podnadpis:    b?.podnadpis             || "",
    popis:        b?.popis                 || "",
    datum:        b?.datum                 || "",
    cas:          b?.cas                   || "",
    misto:        b?.misto                 || "",
    cena:         b?.cena                  || "",
    kontakt:      b?.kontakt               || "",
    web:          b?.web                   || "",
    fotoUrl:      b?.fotoUrl               || "",
    mapUrl:       (b as any)?.mapUrl       || "",
  };
}

const initialState: BrozuraFormState = {};

// ─── Main form ────────────────────────────────────────────────────────────────

interface BrozuraFormProps {
  brozura?: Brozura | null;
}

export function BrozuraForm({ brozura }: BrozuraFormProps) {
  const router = useRouter();
  const isEditing = !!brozura;
  const action = isEditing ? updateBrozura.bind(null, brozura.id) : createBrozura;
  const [state, formAction, isPending] = useActionState(action, initialState);
  const [preview, setPreview] = useState<BrozuraData>(() => defaultPreview(brozura));

  const upd = useCallback((field: keyof BrozuraData, value: string) => {
    setPreview((prev) => ({ ...prev, [field]: value }));
  }, []);

  // When theme toggle changes, apply full color preset
  const handleTema = useCallback((tema: string) => {
    const colors = tema === "SVETLE" ? TEMA_SVETLE : TEMA_TMAVE;
    setPreview((prev) => ({ ...prev, tema, ...colors }));
  }, []);

  useEffect(() => {
    if (state.success) {
      if (state.id) router.push(`/admin/brozury/${state.id}`);
      else router.push("/admin/brozury");
    }
  }, [state.success, state.id, router]);

  return (
    <div className="flex gap-6 min-h-0">

      {/* ── Left: scrollable form ── */}
      <div className="flex-1 min-w-0 overflow-y-auto">
        <form action={formAction} className="space-y-5 pb-12">

          {state.error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
              {state.error}
            </div>
          )}

          {/* Hidden fields for color/layout/orientace values */}
          <input type="hidden" name="tema"         value={preview.tema} />
          <input type="hidden" name="layout"       value={preview.layout} />
          <input type="hidden" name="orientace"    value={preview.orientace} />
          <input type="hidden" name="barvaPozadi"  value={preview.barvaPozadi} />
          <input type="hidden" name="barvaText"    value={preview.barvaText} />
          <input type="hidden" name="barvaAkcentu" value={preview.barvaAkcentu} />

          {/* ── Základní nastavení ── */}
          <Section title="Základní nastavení">
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <Label>Interní název</Label>
                <input name="nazev" required defaultValue={brozura?.nazev}
                  placeholder="např. Zvěřinové hody – říjen 2025"
                  className="input-field" />
                <p className="text-xs text-gray-400 mt-1">Viditelný pouze v adminu</p>
              </div>
              <div>
                <Label>Šablona</Label>
                <select name="sablona" defaultValue={(brozura as any)?.sablona || "AKCE"}
                  onChange={(e) => upd("sablona", e.target.value)} className="input-field">
                  {SABLONA_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </div>
              <div>
                <Label>Kategorie</Label>
                <select name="kategorie" defaultValue={(brozura as any)?.kategorie || "OSTATNI"} className="input-field">
                  {KATEGORIE_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </div>
              {isEditing && (
                <div>
                  <Label>Stav</Label>
                  <select name="stav" defaultValue={(brozura as any)?.stav} className="input-field">
                    {STAV_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                  </select>
                </div>
              )}
            </div>
          </Section>

          {/* ── Vzhled a layout ── */}
          <Section title="Vzhled a layout">
            <div className="space-y-5">

              {/* Téma toggle */}
              <div>
                <Label>Barevné téma</Label>
                <div className="flex gap-3 mt-1">
                  {[
                    { value: "TMAVE", label: "🌙 Tmavé", bg: "#1c1008", text: "#fdf6e3", acc: "#c9a547" },
                    { value: "SVETLE", label: "☀️ Světlé", bg: "#fdf6e3", text: "#1c1008", acc: "#c9a547" },
                  ].map((t) => (
                    <button key={t.value} type="button"
                      onClick={() => handleTema(t.value)}
                      className={`flex-1 flex items-center gap-2 px-4 py-3 rounded-lg border-2 transition-all text-sm font-medium ${
                        preview.tema === t.value
                          ? "border-primary-500 bg-primary-50 text-primary-700"
                          : "border-gray-200 text-gray-600 hover:border-gray-300"
                      }`}
                    >
                      <span className="text-base">{t.label.split(" ")[0]}</span>
                      <span>{t.label.split(" ").slice(1).join(" ")}</span>
                      {/* Mini swatch */}
                      <div className="ml-auto flex gap-1">
                        <div className="w-4 h-4 rounded-full border border-gray-200" style={{ background: t.bg }} />
                        <div className="w-4 h-4 rounded-full border border-gray-200" style={{ background: t.acc }} />
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom colors */}
              <div>
                <Label>Vlastní barvy</Label>
                <div className="grid grid-cols-3 gap-3 mt-1">
                  <ColorPicker label="Pozadí" value={preview.barvaPozadi}
                    onChange={(v) => upd("barvaPozadi", v)} />
                  <ColorPicker label="Text" value={preview.barvaText}
                    onChange={(v) => upd("barvaText", v)} />
                  <ColorPicker label="Akcent / zlatá" value={preview.barvaAkcentu}
                    onChange={(v) => upd("barvaAkcentu", v)} />
                </div>
              </div>

              {/* Layout */}
              <div>
                <Label>Layout</Label>
                <div className="grid grid-cols-2 gap-2 mt-1">
                  {LAYOUT_OPTIONS.map((l) => (
                    <button key={l.value} type="button"
                      onClick={() => upd("layout", l.value)}
                      className={`text-left px-3 py-2.5 rounded-lg border-2 transition-all ${
                        preview.layout === l.value
                          ? "border-primary-500 bg-primary-50"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      <div className="text-xs font-semibold text-gray-800">{l.value}</div>
                      <div className="text-xs text-gray-500 mt-0.5">{l.label.split("—")[1]?.trim()}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Format + Orientace */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Formát tisku</Label>
                  <select name="format" value={preview.format}
                    onChange={(e) => upd("format", e.target.value)} className="input-field">
                    {FORMAT_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                  </select>
                </div>
                <div>
                  <Label>Orientace</Label>
                  <div className="flex gap-2 mt-1">
                    {ORIENTACE_OPTIONS.map((o) => (
                      <button key={o.value} type="button"
                        onClick={() => upd("orientace", o.value)}
                        className={`flex-1 text-xs px-3 py-2.5 rounded-lg border-2 transition-all font-medium ${
                          preview.orientace === o.value
                            ? "border-primary-500 bg-primary-50 text-primary-700"
                            : "border-gray-200 text-gray-600 hover:border-gray-300"
                        }`}
                      >
                        {o.value === "PORTRAIT" ? "↕ Na výšku" : "↔ Na šírku"}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </Section>

          {/* ── Obsah ── */}
          <Section title="Obsah brožury">
            <div className="space-y-4">
              <div>
                <Label required>Hlavní nadpis</Label>
                <input name="nadpis" required defaultValue={brozura?.nadpis}
                  placeholder="např. Zvěřinové hody 2025" className="input-field text-base font-medium"
                  onChange={(e) => upd("nadpis", e.target.value)} />
              </div>
              <div>
                <Label>Podnadpis</Label>
                <input name="podnadpis" defaultValue={brozura?.podnadpis || ""}
                  placeholder="např. Tradiční podzimní slavnost" className="input-field"
                  onChange={(e) => upd("podnadpis", e.target.value)} />
              </div>
              <div>
                <Label>Popis / Program</Label>
                <textarea name="popis" rows={4} defaultValue={brozura?.popis || ""}
                  placeholder="Stručný popis akce nebo programu…"
                  className="input-field resize-none"
                  onChange={(e) => upd("popis", e.target.value)} />
              </div>
            </div>
          </Section>

          {/* ── Datum, místo a cena ── */}
          <Section title="Datum, místo a cena">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Datum</Label>
                <input name="datum" defaultValue={brozura?.datum || ""}
                  placeholder="např. 15. 10. 2025" className="input-field"
                  onChange={(e) => upd("datum", e.target.value)} />
              </div>
              <div>
                <Label>Čas</Label>
                <input name="cas" defaultValue={brozura?.cas || ""}
                  placeholder="např. od 18:00" className="input-field"
                  onChange={(e) => upd("cas", e.target.value)} />
              </div>
              <div>
                <Label>Místo</Label>
                <input name="misto" defaultValue={brozura?.misto || ""}
                  placeholder="např. Restaurace U Šimáka" className="input-field"
                  onChange={(e) => upd("misto", e.target.value)} />
              </div>
              <div>
                <Label>Cena / vstupné</Label>
                <input name="cena" defaultValue={brozura?.cena || ""}
                  placeholder="např. 350 Kč / zdarma" className="input-field"
                  onChange={(e) => upd("cena", e.target.value)} />
              </div>
              <div className="col-span-2">
                <Label>Kontakt pro rezervace</Label>
                <input name="kontakt" defaultValue={brozura?.kontakt || ""}
                  placeholder="např. +420 777 000 111" className="input-field"
                  onChange={(e) => upd("kontakt", e.target.value)} />
              </div>
            </div>
          </Section>

          {/* ── Média ── */}
          <Section title="Fotografie a QR kód">
            <div className="space-y-4">
              <div>
                <Label>URL hlavní fotografie</Label>
                <input name="fotoUrl" type="url" defaultValue={brozura?.fotoUrl || ""}
                  placeholder="https://…" className="input-field"
                  onChange={(e) => upd("fotoUrl", e.target.value)} />
                {preview.fotoUrl && (
                  <div className="mt-2 rounded-lg overflow-hidden h-24 bg-gray-100">
                    <img src={preview.fotoUrl} alt="" className="w-full h-full object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
                  </div>
                )}
              </div>
              <div>
                <Label>URL pro QR kód</Label>
                <input name="web" type="url" defaultValue={brozura?.web || ""}
                  placeholder="https://hotel-simak.cz/akce/…" className="input-field"
                  onChange={(e) => upd("web", e.target.value)} />
              </div>
            </div>
          </Section>

          {/* ── Mapa ── */}
          <Section title="Mapa / trasa">
            <div className="space-y-3">
              <p className="text-xs text-gray-500">
                Vlož URL statické mapy (Google Static Maps API, Mapy.cz apod.) nebo screenshot trasy.
                Zobrazí se jako obrázek v brožuře.
              </p>
              <div>
                <Label>URL mapy / trasy</Label>
                <input name="mapUrl" type="url" defaultValue={(brozura as any)?.mapUrl || ""}
                  placeholder="https://maps.googleapis.com/maps/api/staticmap?…" className="input-field"
                  onChange={(e) => upd("mapUrl", e.target.value)} />
              </div>
              {preview.mapUrl && (
                <div className="rounded-lg overflow-hidden h-28 bg-gray-100">
                  <img src={preview.mapUrl} alt="Náhled mapy" className="w-full h-full object-cover"
                    onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
                </div>
              )}
              <p className="text-xs text-gray-400">
                💡 Tip: <a href="https://developers.google.com/maps/documentation/maps-static/start" target="_blank" className="underline">Google Static Maps</a>{" "}
                nebo <a href="https://mapy.cz" target="_blank" className="underline">Mapy.cz</a> → Sdílet → Odkaz na mapu
              </p>
            </div>
          </Section>

          {/* ── Tagy ── */}
          <Section title="Tagy pro vyhledávání">
            <Label>Tagy (oddělené čárkou)</Label>
            <input name="tagy" defaultValue={(brozura as any)?.tagy?.join(", ") || ""}
              placeholder="např. zvěřina, podzim, hody, 2025" className="input-field" />
          </Section>

          {/* ── Akce ── */}
          <div className="flex items-center gap-3 pt-2">
            <button type="submit" disabled={isPending}
              className="btn-primary disabled:opacity-60 flex items-center gap-2">
              {isPending ? (
                <><svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/>
                </svg>Ukládám…</>
              ) : isEditing ? "Uložit změny" : "Vytvořit brožuru"}
            </button>
            <button type="button" onClick={() => router.back()} className="btn-outline">Zrušit</button>
            {isEditing && (
              <div className="flex items-center gap-2 ml-auto">
                <a href={`/api/brozury/${brozura.id}/pdf`}
                  className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900 border border-gray-200 rounded-lg px-4 py-2.5 hover:bg-gray-50 transition-colors">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3M3 17v3a1 1 0 001 1h16a1 1 0 001-1v-3"/>
                  </svg>PDF
                </a>

              </div>
            )}
          </div>
        </form>
      </div>

      {/* ── Right: sticky preview ── */}
      <div className="w-[340px] flex-shrink-0">
        <div className="sticky top-6">
          <BrozuraNahled data={preview} />
        </div>
      </div>
    </div>
  );
}

// ─── Sub-components ──────────────────────────────────────────────────────────

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
      <div className="px-5 py-3 border-b border-gray-100 bg-gray-50">
        <h3 className="text-sm font-semibold text-gray-700">{title}</h3>
      </div>
      <div className="p-5">{children}</div>
    </div>
  );
}

function Label({ children, required }: { children: React.ReactNode; required?: boolean }) {
  return (
    <label className="block text-sm font-medium text-gray-700 mb-1.5">
      {children}{required && <span className="text-red-400 ml-0.5">*</span>}
    </label>
  );
}

function ColorPicker({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div className="flex flex-col gap-1">
      <span className="text-xs text-gray-500">{label}</span>
      <div className="flex items-center gap-2">
        <input type="color" value={value} onChange={(e) => onChange(e.target.value)}
          className="w-10 h-9 rounded border border-gray-200 cursor-pointer p-0.5 bg-white" />
        <input type="text" value={value} onChange={(e) => onChange(e.target.value)}
          className="flex-1 text-xs border border-gray-200 rounded px-2 py-1.5 font-mono focus:outline-none focus:ring-1 focus:ring-primary-400" />
      </div>
    </div>
  );
}
