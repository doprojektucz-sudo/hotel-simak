"use client";

import { useState, useEffect, useRef } from "react";
import { Send } from "lucide-react";
import { sendContactEmail } from "@/app/actions/send-email";

const RECAPTCHA_SITE_KEY = process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY!;

declare global {
    interface Window {
        grecaptcha: {
            render: (
                container: string | HTMLElement,
                parameters: {
                    sitekey: string;
                    callback: (token: string) => void;
                    "expired-callback": () => void;
                    "error-callback": () => void;
                }
            ) => number;
            reset: (widgetId?: number) => void;
            getResponse: (widgetId?: number) => string;
        };
        onRecaptchaLoad: () => void;
    }
}

export default function ContactForm() {
    const [formData, setFormData] = useState({
        name: "",
        email: "",
        phone: "",
        subject: "",
        message: "",
    });

    const [recaptchaToken, setRecaptchaToken] = useState<string>("");
    const [status, setStatus] = useState<"idle" | "sending" | "success" | "error">("idle");
    const [errorMessage, setErrorMessage] = useState<string>("");
    const recaptchaRef = useRef<HTMLDivElement>(null);
    const widgetIdRef = useRef<number | null>(null);
    const [recaptchaLoaded, setRecaptchaLoaded] = useState(false);

    // Načti reCAPTCHA v2 script
    useEffect(() => {
        if (typeof window === "undefined") return;

        // Callback když se reCAPTCHA načte
        window.onRecaptchaLoad = () => {
            setRecaptchaLoaded(true);
        };

        // Přidej script pokud ještě není
        if (!document.querySelector('script[src*="recaptcha/api.js"]')) {
            const script = document.createElement("script");
            script.src = `https://www.google.com/recaptcha/api.js?onload=onRecaptchaLoad&render=explicit&hl=cs`;
            script.async = true;
            script.defer = true;
            document.head.appendChild(script);
        } else if (window.grecaptcha) {
            setRecaptchaLoaded(true);
        }

        return () => {
            window.onRecaptchaLoad = () => { };
        };
    }, []);

    // Renderuj reCAPTCHA widget když je script načtený
    useEffect(() => {
        if (!recaptchaLoaded || !recaptchaRef.current || widgetIdRef.current !== null) return;

        try {
            widgetIdRef.current = window.grecaptcha.render(recaptchaRef.current, {
                sitekey: RECAPTCHA_SITE_KEY,
                callback: (token: string) => {
                    setRecaptchaToken(token);
                },
                "expired-callback": () => {
                    setRecaptchaToken("");
                },
                "error-callback": () => {
                    setRecaptchaToken("");
                    console.error("reCAPTCHA error");
                },
            });
        } catch (error) {
            console.error("Failed to render reCAPTCHA:", error);
        }
    }, [recaptchaLoaded]);

    const resetRecaptcha = () => {
        if (widgetIdRef.current !== null && window.grecaptcha) {
            window.grecaptcha.reset(widgetIdRef.current);
            setRecaptchaToken("");
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setStatus("sending");
        setErrorMessage("");

        // Kontrola reCAPTCHA
        if (!recaptchaToken) {
            setStatus("error");
            setErrorMessage("Prosím potvrďte, že nejste robot.");
            return;
        }

        try {
            const result = await sendContactEmail({
                ...formData,
                recaptchaToken,
            });

            if (result.success) {
                setStatus("success");
                setFormData({
                    name: "",
                    email: "",
                    phone: "",
                    subject: "",
                    message: "",
                });
                resetRecaptcha();

                setTimeout(() => {
                    setStatus("idle");
                }, 5000);
            } else {
                setStatus("error");
                setErrorMessage(result.error || "Nastala neočekávaná chyba");
                resetRecaptcha();
            }
        } catch (error) {
            console.error("Form submission error:", error);
            setStatus("error");
            setErrorMessage("Nepodařilo se odeslat zprávu. Zkuste to prosím později.");
            resetRecaptcha();
        }
    };

    const handleChange = (
        e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
    ) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-6">
            {/* Name */}
            <div>
                <label
                    htmlFor="name"
                    className="block text-sm font-semibold text-gray-900 mb-2"
                >
                    Jméno a příjmení *
                </label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    placeholder="Jan Novák"
                />
            </div>

            {/* Email */}
            <div>
                <label
                    htmlFor="email"
                    className="block text-sm font-semibold text-gray-900 mb-2"
                >
                    Email *
                </label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    placeholder="jan.novak@email.cz"
                />
            </div>

            {/* Phone */}
            <div>
                <label
                    htmlFor="phone"
                    className="block text-sm font-semibold text-gray-900 mb-2"
                >
                    Telefon
                </label>
                <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    placeholder="+420 123 456 789"
                />
            </div>

            {/* Subject */}
            <div>
                <label
                    htmlFor="subject"
                    className="block text-sm font-semibold text-gray-900 mb-2"
                >
                    Předmět *
                </label>
                <select
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white"
                >
                    <option value="">Vyberte předmět...</option>
                    <option value="ubytovani">Rezervace ubytování</option>
                    <option value="restaurace">Rezervace stolu v restauraci</option>
                    <option value="akce">Poptávka akce/oslavy</option>
                    <option value="chata">Rezervace chaty Milunda</option>
                    <option value="jine">Jiný dotaz</option>
                </select>
            </div>

            {/* Message */}
            <div>
                <label
                    htmlFor="message"
                    className="block text-sm font-semibold text-gray-900 mb-2"
                >
                    Zpráva *
                </label>
                <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={6}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent resize-none"
                    placeholder="Napište nám svůj dotaz nebo požadavek..."
                />
            </div>

            {/* reCAPTCHA v2 widget */}
            <div className="flex justify-center">
                <div ref={recaptchaRef}></div>
            </div>

            {/* Submit Button */}
            <div>
                <button
                    type="submit"
                    disabled={status === "sending" || !recaptchaToken}
                    className="w-full bg-primary-600 hover:bg-primary-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white font-semibold py-4 px-8 rounded-lg transition-colors duration-200 flex items-center justify-center gap-2"
                >
                    {status === "sending" ? (
                        <>
                            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                            Odesílám...
                        </>
                    ) : (
                        <>
                            <Send className="w-5 h-5" />
                            Odeslat zprávu
                        </>
                    )}
                </button>
            </div>

            {/* Success Message */}
            {status === "success" && (
                <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg">
                    <p className="font-semibold">Zpráva byla úspěšně odeslána!</p>
                    <p className="text-sm">
                        Děkujeme za Vaši zprávu. Ozveme se Vám co nejdříve. Na Váš email jsme Vám
                        poslali potvrzení.
                    </p>
                </div>
            )}

            {/* Error Message */}
            {status === "error" && (
                <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg">
                    <p className="font-semibold">Nepodařilo se odeslat zprávu.</p>
                    <p className="text-sm">
                        {errorMessage ||
                            "Zkuste to prosím později nebo nás kontaktujte přímo telefonicky na 728 490 498."}
                    </p>
                </div>
            )}
        </form>
    );
}